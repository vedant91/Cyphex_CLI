/**
 * VibeMart Attack Simulator
 * Sends various attack payloads to the VibeMart API to test Cyphex RASP.
 */
const http = require('http');

function attack(name, options, body) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : '';
    const req = http.request({
      hostname: '127.0.0.1',
      port: 3003,
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
      }
    }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => {
        console.log(`\n[${name}] Status: ${res.statusCode}`);
        try {
          const json = JSON.parse(chunks);
          console.log(JSON.stringify(json, null, 2));
        } catch { console.log(chunks); }
        resolve();
      });
    });
    req.on('error', (e) => {
      console.log(`\n[${name}] ERROR: ${e.message}`);
      resolve();
    });
    if (data) req.write(data);
    req.end();
  });
}

async function main() {
  console.log('=== CYPHEX RASP LIVE TEST ===\n');

  // Attack 1: SQL Injection on Login
  await attack(
    'SQLi - Login',
    { method: 'POST', path: '/api/users/login' },
    { username: "' OR 1=1 --", password: 'x' }
  );

  // Attack 2: SQL Injection on Product Search
  await attack(
    'SQLi - Search',
    { method: 'GET', path: "/api/products/search?q=" + encodeURIComponent("' UNION SELECT * FROM users --") },
    null
  );

  // Attack 3: Command Injection on Admin Ping
  await attack(
    'CMDi - Ping',
    { method: 'POST', path: '/api/admin/ping' },
    { host: '127.0.0.1; cat /etc/passwd' }
  );

  // Attack 4: XSS in Product Search
  await attack(
    'XSS - Search',
    { method: 'GET', path: '/api/products/search?q=' + encodeURIComponent('<script>alert("xss")</script>') },
    null
  );

  console.log('\n=== ALL ATTACKS SENT ===');
}

main();
